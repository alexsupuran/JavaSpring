package com.alex.models;

public class LoginModel {
	private String Username;
	private String Password;
	
	@Override
	public String toString() {
		return "LoginModel [Username=" + Username + ", Password=" + Password + "]";
	}
	public LoginModel() {
		super();
	}
	public LoginModel(String username, String password) {
		super();
		Username = username;
		Password = password;
	}
	public String getUsername() {
		return Username;
	}
	public void setUsername(String username) {
		Username = username;
	}
	public String getPassword() {
		return Password;
	}
	public void setPassword(String password) {
		Password = password;
	}
	
}

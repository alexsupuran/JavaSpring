package com.alex;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.ComponentScan;

@SpringBootApplication
@ComponentScan("com.alex")
public class Topic2Application {

	public static void main(String[] args) {
		SpringApplication.run(Topic2Application.class, args);
	}

}

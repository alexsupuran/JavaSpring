package com.alex.models;

public class OrderModel {
	Long id=0L;
	String orderNo="";
	String productName="";
	float price=0;
	int quantity=0;
	public OrderModel(Long id, String orderNO, String productName, float price, int quantity) {
		super();
		this.id = id;
		this.orderNo = orderNO;
		this.productName = productName;
		this.price = price;
		this.quantity = quantity;
	}
	@Override
	public String toString() {
		return "OrderModel [id=" + id + ", orderNo=" + orderNo + ", productName=" + productName + ", price=" + price
				+ ", quantity=" + quantity + "]";
	}
	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	public String getOrderNo() {
		return orderNo;
	}
	public void setOrderNo(String orderNO) {
		this.orderNo = orderNO;
	}
	public String getProductName() {
		return productName;
	}
	public void setProductName(String productName) {
		this.productName = productName;
	}
	public float getPrice() {
		return price;
	}
	public void setPrice(float price) {
		this.price = price;
	}
	public int getQuantity() {
		return quantity;
	}
	public OrderModel() {
		super();
	}
	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}
	
}

package com.alex;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Topic44Application {

	public static void main(String[] args) {
		SpringApplication.run(Topic44Application.class, args);
	}

}

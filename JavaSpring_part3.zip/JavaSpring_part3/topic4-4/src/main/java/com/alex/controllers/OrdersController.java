package com.alex.controllers;

import java.util.ArrayList;
import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import com.alex.models.OrderModel;
import com.alex.models.SearchModel;
import com.alex.services.OrdersBusinessServiceInterface;
import com.alex.services.OrdersBusinessService;

@Controller
@RequestMapping("/orders")
public class OrdersController {
	
	@Autowired
	OrdersBusinessServiceInterface service;
	
	public OrdersController(OrdersBusinessServiceInterface ordersBusinessService) {
		super();
		this.service = ordersBusinessService;
	}

	@GetMapping("/")
	public String showAllOrder(Model model) {
	List<OrderModel>orders=service.getOrders();
	model.addAttribute("title","Here is what I want to do this summer");
	model.addAttribute("orders",orders);
	return "orders.html";
	}
	
	@GetMapping("/showNewOrderForm")
	public String showNewForm(Model model) {
		model.addAttribute("order", new OrderModel());
		return "addNewOrderForm.html";
	}
	@PostMapping("/addNew")
	public String addnew(@Valid OrderModel newOrder, BindingResult bindingResult,Model model) {
		newOrder.setId(null);
		service.addOne(newOrder);
		List<OrderModel> orders=service.getOrders();
		model.addAttribute("orders",orders);
		return "orders";	
	}
	@GetMapping("/showSearchForm")
	public String showSearchForm(Model model) {
		model.addAttribute("searchModel", new SearchModel());
		return "searchForm.html";
	}
	@PostMapping("/search")
	public String search(@Valid SearchModel searchModel, BindingResult bindingResult,Model model)
	{
		String searchTerm=searchModel.getSearchTerm();
		List<OrderModel> orders=service.searchOrders(searchTerm);
		model.addAttribute("orders",orders);
		return "orders";
	}
	@GetMapping("/admin")
	public String showAdminPage(Model model) {
	List<OrderModel>orders=service.getOrders();
	model.addAttribute("title","Here is what I want to do this summer");
	model.addAttribute("orders",orders);
	return "ordersAdmin.html";
	}
	@PostMapping("/doUpdate")
	public String doUpdate(@Valid OrderModel order, BindingResult bindingResult,Model model)
	{
		service.updateOne(order.getId(), order);
		List<OrderModel> orders=service.getOrders();
		model.addAttribute("orders",orders);
		return "ordersAdmin";
	}
	@PostMapping("/editForm")
	public String displayEditForm(@Valid OrderModel orderModel, Model model)
	{
		model.addAttribute("title","Edit order");
		model.addAttribute("orderModel",orderModel);
		return "editForm.html";
	}
	@PostMapping("/delete/")
	public String delete(@Valid OrderModel order, BindingResult bindingResult,Model model)
	{
		service.deleteOne(order.getId());
		List<OrderModel> orders=service.getOrders();
		model.addAttribute("orders",orders);
		return "ordersAdmin.html";
	}
	@GetMapping("/spa")
	public String showSPApage(Model model) {
		return "ordersSPA.html";
	}
}
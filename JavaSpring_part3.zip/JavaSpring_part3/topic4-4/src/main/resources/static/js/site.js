$(document).ready(function() {
    console.log("ready");
    $("#entry-form").hide();
    $("#search-button").click(function() {
        $("#entry-form").hide(500);
        var searchTerm = $("#searchTerm").val();
        console.log("You searched for " + searchTerm);
        $.ajax({
            url: "http://localhost:8080/api/v1/orders/search/" + searchTerm,
            success: function(result) {
                console.log(result);
                var outputHTML="";
                for(var x=0;x<result.length;x++){
                    var order=result[x];
                    outputHTML+="<div class='single-order'><ul>";
                    outputHTML+="<li>Id:"+order.id+"</li>";
                    outputHTML+="<li>OrderNumber:"+order.orderNo+"</li>";
                    outputHTML+="<li>ProductName:"+order.productName+"</li>";
                    outputHTML+="<li>Price:"+order.price+"</li>";
                    outputHTML+="<li>Quantity:"+order.quantity+"</li>";
                    outputHTML+="</ul>";
                    outputHTML+="<button class='edit-button btn btn-secondary' value='"+order.id+"'>Edit</button>";
                    outputHTML+="<button class='delete-button btn btn-primary' value='"+order.id+"'>Delete</button>";
                    outputHTML+="</div>";
                }
                $("#results-box").html(outputHTML);
            }
        });
    });

    $(document).on("click", ".edit-button", function() {
        const editIdNumber = $(this).val();
        console.log(editIdNumber);
        $.ajax({
            url: "http://localhost:8080/api/v1/orders/" + editIdNumber,
            type: "GET",
            success: function(result) {
                console.log(result);
                $("#orderid").val(result.id);
                $("#ordernumber").val(result.orderNo);
                $("#orderproductname").val(result.productName);
                $("#orderprice").val(result.price);
                $("#orderquantity").val(result.quantity);
                $("#entry-form").show(500);
            }
        });
    });

    $("#form-ok").click(function() {
        var obj = new Object();
        obj.id = $("#orderid").val();
        obj.orderNo = $("#ordernumber").val();
        obj.productName = $("#orderproductname").val();
        obj.price = $("#orderprice").val();
        obj.quantity = $("#orderquantity").val();
        var jsonString = JSON.stringify(obj);
        console.log("jsonstring", jsonString);
        $.ajax({
            type: 'PUT',
            url: "http://localhost:8080/api/v1/orders/update/" + obj.id,
            contentType: "application/json",
            data: jsonString,
            dataType: 'json',
            success: function(data) {
                console.log(data);
            },
            error: function(e) {
                console.log(e);
            },
        });
        $("#entry-form").hide(500);
        $("#results-box").html("");
    });
    
     $(document).on("click", ".delete-button", function() {
		 const deleteIdNumber=$(this).val();
		 console.log(deleteIdNumber);
		 $.ajax(
			 {
				 type:'DELETE',
				 url:"http://localhost:8080/api/v1/orders/"+deleteIdNumber,
				 success:function(data){
					 console.log(data);
				 },
				 error: function(e){
					 console.log(e);
				 },
			 }),
		 $("#results-box").html("");});
    
});

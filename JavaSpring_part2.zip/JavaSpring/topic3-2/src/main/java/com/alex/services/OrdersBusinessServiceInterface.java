package com.alex.services;

import java.util.List;

import com.alex.models.OrderModel;

public interface OrdersBusinessServiceInterface {
	public void test();
	public List<OrderModel> getOrders();
	public void init();
	public void destroy();
}

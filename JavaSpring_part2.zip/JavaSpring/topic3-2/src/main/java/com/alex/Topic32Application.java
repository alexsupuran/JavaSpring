package com.alex;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Topic32Application {

	public static void main(String[] args) {
		SpringApplication.run(Topic32Application.class, args);
	}

}

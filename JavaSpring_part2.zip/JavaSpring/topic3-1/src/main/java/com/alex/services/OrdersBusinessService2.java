package com.alex.services;

import java.util.ArrayList;
import java.util.List;

import org.springframework.context.annotation.Primary;
import org.springframework.stereotype.Service;

import com.alex.models.OrderModel;

public class OrdersBusinessService2 implements OrdersBusinessServiceInterface {

	@Override
	public void test() {
		System.out.println("OrderBusinessService is working");
		
	}

	@Override
	public List<OrderModel> getOrders() {
		List<OrderModel> orders=new ArrayList<OrderModel>();
		orders.add(new OrderModel(0L,"AAA","Big Mac",1500.0f,1));	
		orders.add(new OrderModel(1L,"AAB","Large Fries",120.0f,5));	
		orders.add(new OrderModel(2L,"AAC","Chicken Nuggets",500000000.0f,2));
		orders.add(new OrderModel(3L,"AAD","Coke",420.0f,1));
		orders.add(new OrderModel(4L,"AAE","Apple pie",470.0f,1));
		return orders;
	}
	
}

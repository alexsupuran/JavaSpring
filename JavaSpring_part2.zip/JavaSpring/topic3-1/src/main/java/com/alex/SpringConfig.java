package com.alex;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import com.alex.services.OrdersBusinessService;
import com.alex.services.OrdersBusinessService2;
import com.alex.services.OrdersBusinessServiceInterface;

@Configuration
public class SpringConfig {
	@Bean(name="ordersBusinessService")
	public OrdersBusinessServiceInterface getOrdersBusiness() {
		return new OrdersBusinessService2();
	}
}

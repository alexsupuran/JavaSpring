package com.alex.data;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

import org.springframework.stereotype.Repository;

import com.alex.models.OrderModel;

@Repository
public class OrdersFakeDAO implements OrdersDataAccessInterface {

	List<OrderModel> orders=new ArrayList<OrderModel>();
	
	
	public OrdersFakeDAO() {
		
		
	}

	@Override
	public OrderModel getById(long id) {
		for(int i=0;i<orders.size();i++) {
			if(orders.get(i).getId()==id)
				return orders.get(i);
		}
		return null;
	}

	@Override
	public List<OrderModel> getOrders() {
		return orders;
	}

	@Override
	public List<OrderModel> searchOrders(String searchTerm) {
		/*
		List<OrderModel>foundItems=new ArrayList<OrderModel>();
		for(int i=0;i<orders.size();i++)
			if(orders.get(i).getProductName().toLowerCase().contains(searchTerm.toLowerCase()))
				foundItems.add(orders.get(i));
		return foundItems;*/
		List<OrderModel> foundItems=orders
				.stream()
				.filter(order->order.getProductName().toLowerCase()
						.contains(searchTerm.toLowerCase()))
				.collect(Collectors.toList());
		return foundItems;
	}

	@Override
	public long addOne(OrderModel newOrder) {
		boolean success=orders.add(newOrder);
		if(success) {
			return 1;
		}
		else {
			return 0;
		}
	}

	@Override
	public boolean deleteOne(long id) {
		for(int i=0;i<orders.size();i++) 
			{if(orders.get(i).getId()==id) {orders.remove(i);
		    								return true;}
			}
	return false;
	}

	@Override
	public OrderModel updateOne(long idToUpdate, OrderModel updateOrder) {
		for(int i=0;i<orders.size();i++) 
			{
				if(orders.get(i).getId()==idToUpdate) 
					{ orders.set(i,updateOrder);
					  return orders.get(i);
					}
			}
		return null;
		
	}

}

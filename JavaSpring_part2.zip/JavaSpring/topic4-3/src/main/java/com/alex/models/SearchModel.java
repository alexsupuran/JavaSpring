package com.alex.models;

public class SearchModel {
	String searchTerm;

	public SearchModel() {
		super();
	}

	public String getSearchTerm() {
		return searchTerm;
	}

	public void setSearchTerm(String searchTerm) {
		this.searchTerm = searchTerm;
	}
	
}

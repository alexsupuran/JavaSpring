package com.alex.data;

import java.util.List;

import org.springframework.data.repository.CrudRepository;

import com.alex.models.OrderEntity;

public interface OrdersRepositoryInterface extends CrudRepository<OrderEntity,Long> {
	
	List<OrderEntity> findByProductNameContainingIgnoreCase(String searchTerm);
}

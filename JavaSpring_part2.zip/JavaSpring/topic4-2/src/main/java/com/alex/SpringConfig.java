package com.alex;

import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.context.annotation.RequestScope;
import org.springframework.web.context.annotation.SessionScope;

import com.alex.data.OrdersDataAccessInterface;
import com.alex.data.OrdersDataService;
import com.alex.data.OrdersDataServiceForRepository;
import com.alex.services.OrdersBusinessService;
import com.alex.services.OrdersBusinessServiceInterface;
@Configuration
public class SpringConfig {
	@Bean(name="ordersBusinessService",initMethod="init",destroyMethod="destroy")
	@RequestScope
	public OrdersBusinessServiceInterface getOrdersBusiness() {
		return new OrdersBusinessService();
	}
	
	@Autowired
	DataSource dataSource;
	
	@Bean(name="ordersDAO")
	@RequestScope
	public OrdersDataAccessInterface getDataService() {
		return new OrdersDataServiceForRepository(dataSource);
		// return new OrdersDataService();
	}
}
